//navigation bar (Material Design)
